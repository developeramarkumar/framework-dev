import { Component } from '@angular/core';
@Component({
 	selector: 'ng-router',
 	templateUrl: '/admin/pages/dashboard.component.html?dir=html',
})
export class DashboardComponent { }
