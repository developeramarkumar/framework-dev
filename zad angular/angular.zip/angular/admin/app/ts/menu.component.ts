import { Component } from '@angular/core';
@Component({
 	selector: 'ng-router',
 	templateUrl: '/admin/pages/menu.component.html?dir=html',
})
export class MenuComponent {  }
