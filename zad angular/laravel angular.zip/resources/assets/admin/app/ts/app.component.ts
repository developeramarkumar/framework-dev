import { Component } from '@angular/core';
//import { Router,Event as RouterEvent,NavigationStart,NavigationEnd,NavigationCancel,NavigationError }   from '@angular/router';

@Component({
 	selector: 'ng-app',
 	templateUrl: '/admin/pages/app.component.html?dir=html',
 	styleUrls: ['/admin/pages/app.component.css?dir=css'],
})
export class AppComponent { 

}
