import { Component } from '@angular/core';
@Component({
 	selector: 'my-app',
 	templateUrl: '/admin/pages/form.component.html?dir=html&dir2=section',
})
export class SectionComponent { 

 }
