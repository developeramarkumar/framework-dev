<?php 
Route::get('/', function() {
    //
});