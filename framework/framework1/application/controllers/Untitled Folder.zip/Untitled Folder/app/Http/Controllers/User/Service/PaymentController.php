<?php
namespace App\Http\Controllers\User\Service;

use App\Http\Controllers\Controller;

use \Request;
use \Redirect;
use App\Model\Operator;


class PaymentController extends Controller
{

    public function index(){
      
    } 
    public function pay(){
       return 'sdfsd';
    }   
}
