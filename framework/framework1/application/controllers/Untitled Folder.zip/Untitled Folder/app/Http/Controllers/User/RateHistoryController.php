<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\User;
class RateHistoryController extends Controller
{

	
    public function index(Request $request)
    {
    	return $this;
    }
}
