<?php 
namespace App\Http\Library;
/**
* All function for hotel
*/
class Hotel
{
	public function getHotel(){
		return 'ok';
	}
}