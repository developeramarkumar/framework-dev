<?php
namespace App\Model;
use \Illuminate\Database\Eloquent\Model;

class BankList extends Model
{
	protected $table = 'bank_lists';

	
}