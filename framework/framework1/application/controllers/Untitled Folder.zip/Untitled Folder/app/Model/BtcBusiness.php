<?php
namespace App\Model;
use \Illuminate\Database\Eloquent\Model;

class BtcBusiness extends Model
{
	 protected $table = 'btc_business';
	protected $fillable = ['value'];

	
}
