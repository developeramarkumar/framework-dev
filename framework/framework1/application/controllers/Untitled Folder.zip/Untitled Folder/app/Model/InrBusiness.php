<?php
namespace App\Model;
use \Illuminate\Database\Eloquent\Model;

class InrBusiness extends Model
{
	 protected $table = 'inr_business';
	protected $fillable = ['value'];

	
}
