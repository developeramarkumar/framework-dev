<?php
namespace App\Model;
use \Illuminate\Database\Eloquent\Model;

class DepositeSlip extends Model
{
	protected $table = 'bank_deposite_slip';
}
