<?php
namespace App\Model;
use \Illuminate\Database\Eloquent\Model;

class Rechargeorder extends Model
{
	protected $table = 'bill_payment_and_recharge';


	
}
