<?php
namespace App\Model;
use \Illuminate\Database\Eloquent\Model;

class Ibplan extends Model
{
	protected $table = 'ib_plan';
	protected $fillable = ['user_id'];
	
}

