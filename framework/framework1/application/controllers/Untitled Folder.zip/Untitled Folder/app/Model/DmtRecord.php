<?php
namespace App\Model;
use \Illuminate\Database\Eloquent\Model;

class DmtRecord extends Model
{
	// protected $table = 'dmt_records';
	// protected $fillable = ['user_id','image','title'];

	
}
