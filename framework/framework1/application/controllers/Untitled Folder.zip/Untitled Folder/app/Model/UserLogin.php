<?php
namespace App\Model;
use \Illuminate\Database\Eloquent\Model;

class UserLogin extends Model
{
	protected $fillable = ['user_id','ip'];

	
}
