<?php
namespace App\Model;
use \Illuminate\Database\Eloquent\Model;

class CyberplatError extends Model
{
	protected $table = 'hp_cyberplat_response_message';
	
}
