<?php
namespace App\Model;
use \Illuminate\Database\Eloquent\Model;

class Cyberplat extends Model
{
	protected $table = 'hp_cyberplat_details';
	
}
