<?php
namespace App\Model;
use \Illuminate\Database\Eloquent\Model;

class IcoExtra extends Model
{
	protected $table = 'ico_extra_coin';
	protected $fillable = ['id'];

	
}
