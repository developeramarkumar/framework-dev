<?php
namespace Core\Validator;


class Validator
{
   
}